app_name = "medusa_connector"
app_title = "Medusa Connector"
app_publisher = "Aerele"
app_description = "connect erpnext to medusa"
app_email = "karuppasamy@aerele.in"
app_license = "mit"

# Send non-GET requests for this app's endpoints as native `application/json`
# bodies instead of form-encoded, per-key JSON-stringified values.
use_json_request_body = True

# Apps
# ------------------

required_apps = ["erpnext", "ecommerce_core"]

# Each item in the list will be shown as an app in the apps page
# add_to_apps_screen = [
# 	{
# 		"name": "medusa_connector",
# 		"logo": "/assets/medusa_connector/logo.png",
# 		"title": "Medusa Connector",
# 		"route": "/medusa_connector",
# 		"has_permission": "medusa_connector.api.permission.has_app_permission"
# 	}
# ]

# Includes in <head>
# ------------------

# include js, css files in header of desk.html
# app_include_css = "/assets/medusa_connector/css/medusa_connector.css"
# app_include_js = "/assets/medusa_connector/js/medusa_connector.js"

# include js, css files in header of web template
# web_include_css = "/assets/medusa_connector/css/medusa_connector.css"
# web_include_js = "/assets/medusa_connector/js/medusa_connector.js"

# include custom scss in every website theme (without file extension ".scss")
# website_theme_scss = "medusa_connector/public/scss/website"

# include js, css files in header of web form
# webform_include_js = {"doctype": "public/js/doctype.js"}
# webform_include_css = {"doctype": "public/css/doctype.css"}

# include js in page
# page_js = {"page" : "public/js/file.js"}

# include js in doctype views
# doctype_js = {"doctype" : "public/js/doctype.js"}
# doctype_list_js = {"doctype" : "public/js/doctype_list.js"}
# doctype_tree_js = {"doctype" : "public/js/doctype_tree.js"}
# doctype_calendar_js = {"doctype" : "public/js/doctype_calendar.js"}

# Svg Icons
# ------------------
# include app icons in desk
# app_include_icons = "medusa_connector/public/icons.svg"

# Home Pages
# ----------

# application home page (will override Website Settings)
# home_page = "login"

# website user home page (by Role)
# role_home_page = {
# 	"Role": "home_page"
# }

# Generators
# ----------

# automatically create page for each record of this doctype
# website_generators = ["Web Page"]

# automatically load and sync documents of this doctype from downstream apps
# importable_doctypes = [doctype_1]

# Jinja
# ----------

# add methods and filters to jinja environment
# jinja = {
# 	"methods": "medusa_connector.utils.jinja_methods",
# 	"filters": "medusa_connector.utils.jinja_filters"
# }

# Installation
# ------------

# before_install = "medusa_connector.install.before_install"
after_install = "medusa_connector.setup.after_install"

# Uninstallation
# ------------

# before_uninstall = "medusa_connector.uninstall.before_uninstall"
# after_uninstall = "medusa_connector.uninstall.after_uninstall"

# Integration Setup
# ------------------
# To set up dependencies/integrations with other apps
# Name of the app being installed is passed as an argument

# before_app_install = "medusa_connector.utils.before_app_install"
# after_app_install = "medusa_connector.utils.after_app_install"

# Integration Cleanup
# -------------------
# To clean up dependencies/integrations with other apps
# Name of the app being uninstalled is passed as an argument

# before_app_uninstall = "medusa_connector.utils.before_app_uninstall"
# after_app_uninstall = "medusa_connector.utils.after_app_uninstall"

# Build
# ------------------
# To hook into the build process

# after_build = "medusa_connector.build.after_build"

# Desk Notifications
# ------------------
# See frappe.core.notifications.get_notification_config

# notification_config = "medusa_connector.notifications.get_notification_config"

# Permissions
# -----------
# Permissions evaluated in scripted ways

# permission_query_conditions = {
# 	"Event": "frappe.desk.doctype.event.event.get_permission_query_conditions",
# }
#
# has_permission = {
# 	"Event": "frappe.desk.doctype.event.event.has_permission",
# }

# Document Events
# ---------------
# ERPNext → Medusa product upload (gated by Medusa Settings flags).

doc_events = {
	"Item": {
		"after_insert": "medusa_connector.product.export_products.upload_erpnext_item",
		"on_update": "medusa_connector.product.export_products.upload_erpnext_item",
		"on_trash": "medusa_connector.product.export_products.archive_erpnext_item",
	},
}

# Scheduled Tasks
# ---------------

scheduler_events = {
	"all": [
		"medusa_connector.product.inventory_export.update_inventory_on_medusa",
	],
	"hourly_long": [
		"medusa_connector.medusa.client.scheduled_health_check",
		"medusa_connector.medusa.webhook_sync.scheduled_webhook_sync",
		"medusa_connector.order.sync.sync_old_orders",
	],
	"cron": {
		"*/10 * * * *": [
			"medusa_connector.webhook.dispatch.retry_failed_webhooks",
		],
	},
}

# Desk page client scripts are loaded automatically from page/ folders.
# Keep log retention configurable.


# Testing
# -------

# before_tests = "medusa_connector.install.before_tests"

# Extend DocType Class
# ------------------------------
#
# Specify custom mixins to extend the standard doctype controller.
# extend_doctype_class = {
# 	"Task": "medusa_connector.custom.task.CustomTaskMixin"
# }

# Overriding Methods
# ------------------------------
#
# override_whitelisted_methods = {
# 	"frappe.desk.doctype.event.event.get_events": "medusa_connector.event.get_events"
# }
#
# each overriding function accepts a `data` argument;
# generated from the base implementation of the doctype dashboard,
# along with any modifications made in other Frappe apps
# override_doctype_dashboards = {
# 	"Task": "medusa_connector.task.get_dashboard_data"
# }

# exempt linked doctypes from being automatically cancelled
#
# auto_cancel_exempted_doctypes = ["Auto Repeat"]

# Ignore links to specified DocTypes when deleting documents
# -----------------------------------------------------------

# ignore_links_on_delete = ["Communication", "ToDo"]

# Request Events
# ----------------
# before_request = ["medusa_connector.utils.before_request"]
# after_request = ["medusa_connector.utils.after_request"]

# Job Events
# ----------
# before_job = ["medusa_connector.utils.before_job"]
# after_job = ["medusa_connector.utils.after_job"]

# after_file_upload = ["medusa_connector.utils.after_file_upload"]

# User Data Protection
# --------------------

# user_data_fields = [
# 	{
# 		"doctype": "{doctype_1}",
# 		"filter_by": "{filter_by}",
# 		"redact_fields": ["{field_1}", "{field_2}"],
# 		"partial": 1,
# 	},
# 	{
# 		"doctype": "{doctype_2}",
# 		"filter_by": "{filter_by}",
# 		"partial": 1,
# 	},
# 	{
# 		"doctype": "{doctype_3}",
# 		"strict": False,
# 	},
# 	{
# 		"doctype": "{doctype_4}"
# 	}
# ]

# Authentication and authorization
# --------------------------------

# auth_hooks = [
# 	"medusa_connector.auth.validate"
# ]

# Automatically update python controller files with type annotations for this app.
export_python_type_annotations = True

# Require all whitelisted methods to have type annotations
require_type_annotated_api_methods = True

# Translation
# ------------
# List of apps whose translatable strings should be excluded from this app's translations.
# ignore_translatable_strings_from = []
